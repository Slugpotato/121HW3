package com.dealfaro.luca.clicker;

/**
 * Created by ilaforces1 on 5/7/15.
 */
public class CallResult {
    public CallResult() {};
    MsgInfo[] messages;
}