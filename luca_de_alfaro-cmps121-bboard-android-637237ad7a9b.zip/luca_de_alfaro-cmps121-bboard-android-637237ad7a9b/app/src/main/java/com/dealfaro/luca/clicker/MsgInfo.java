package com.dealfaro.luca.clicker;

/**
 * Created by ilaforces1 on 4/28/15.
 */
public class MsgInfo {
    public MsgInfo() {};

    public String msg;
    public String userid;
    public String dest;
    public String ts;
    public String msgid;
    public Boolean conversation;

}

